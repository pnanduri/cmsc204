

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class BasicDoubleLinkedList_STUDENT_Test {
	
	
	BasicDoubleLinkedList<Age> linkedAge;
	
	
	AgeComparator comparatorAge;
	
	public Age a=new Age(10, 40, 43);
	public Age b=new Age(18, 41, 41);
	public Age c=new Age(25, 45, 45);
	public Age d=new Age(30, 60, 61);
	public Age e=new Age(50, 86, 84);
	public Age f=new Age(1, 25, 28);

	public ArrayList<Age> fill = new ArrayList<Age>();
	

	@Before
	public void setUp() throws Exception {
			
		linkedAge= new BasicDoubleLinkedList<Age>();
		linkedAge.addToEnd(b);
		linkedAge.addToEnd(c);
		comparatorAge = new AgeComparator();
	}

	@After
	public void tearDown() throws Exception {
		
		linkedAge = null;
		
	}

	@Test
	public void testGetSize() {
		assertEquals(2,linkedAge.getSize());
	}
	
	@Test
	public void testAddToEnd() {
		
		assertEquals(c,linkedAge.getLast());
		linkedAge.addToEnd(d);
		assertEquals(d,linkedAge.getLast());
	}
	
	@Test
	public void testAddToFront() {	
		assertEquals(b,linkedAge.getFirst());
		linkedAge.addToFront(a);
		assertEquals(a,linkedAge.getFirst());
	}
	
	@Test
	public void testGetFirst() {
		assertEquals(b,linkedAge.getFirst());
		linkedAge.addToFront(a);
		assertEquals(a,linkedAge.getFirst());
	}

	@Test
	public void testGetLast() {	
		assertEquals(c,linkedAge.getLast());
		linkedAge.addToEnd(d);
		assertEquals(d,linkedAge.getLast());
	}
	
	@Test
	public void testToArrayList()
	{
		ArrayList<Age> list;
		linkedAge.addToFront(a);
		linkedAge.addToEnd(d);
		list = linkedAge.toArrayList();
		assertEquals(a,list.get(0));
		assertEquals(b,list.get(1));
		assertEquals(c,list.get(2));
		assertEquals(d,list.get(3));
	}
	
	@Test
	public void testIteratorSuccessfulNext() {
		
		linkedAge.addToFront(a);
		linkedAge.addToEnd(d);
		ListIterator<Age> iteratorCar = linkedAge.iterator();
		assertEquals(true, iteratorCar.hasNext());
		assertEquals(a, iteratorCar.next());
		assertEquals(b, iteratorCar.next());
		assertEquals(c, iteratorCar.next());
		assertEquals(true, iteratorCar.hasNext());
		assertEquals(d, iteratorCar.next());
	}
	
	@Test
	public void testIteratorSuccessfulPrevious() {
		linkedAge.addToFront(a);
		linkedAge.addToEnd(d);
		ListIterator<Age> iteratorCar = linkedAge.iterator();
		assertEquals(true, iteratorCar.hasNext());
		assertEquals(a, iteratorCar.next());
		assertEquals(b, iteratorCar.next());
		assertEquals(c, iteratorCar.next());
		assertEquals(d, iteratorCar.next());
		assertEquals(true, iteratorCar.hasPrevious());
		assertEquals(d, iteratorCar.previous());
		assertEquals(c, iteratorCar.previous());
		assertEquals(b, iteratorCar.previous());
		assertEquals(a, iteratorCar.previous());
	}
	
	@Test
	public void testIteratorNoSuchElementExceptionNext() {
		linkedAge.addToFront(a);
		linkedAge.addToEnd(d);
		ListIterator<Age> iteratorAge = linkedAge.iterator();		
		assertEquals(true, iteratorAge.hasNext());
		assertEquals(a, iteratorAge.next());
		assertEquals(b, iteratorAge.next());
		assertEquals(c, iteratorAge.next());
		assertEquals(true, iteratorAge.hasNext());
		assertEquals(d, iteratorAge.next());
		
		try{
			
			iteratorAge.next();
			assertTrue("Did not throw a NoSuchElementException",false);
		}
		catch (NoSuchElementException e)
		{
			assertTrue("Successfully threw a NoSuchElementException",true);
		}
		catch (Exception e)
		{
			assertTrue("Threw an exception other than the NoSuchElementException", false);
		}
		
	}
	
	@Test
	public void testIteratorNoSuchElementExceptionPrevious() {
		linkedAge.addToFront(a);
		linkedAge.addToEnd(d);
		ListIterator<Age> iteratorAge = linkedAge.iterator();		
		assertEquals(true, iteratorAge.hasNext());
		assertEquals(a, iteratorAge.next());
		assertEquals(b, iteratorAge.next());
		assertEquals(c, iteratorAge.next());
		assertEquals(d, iteratorAge.next());
		assertEquals(true, iteratorAge.hasPrevious());
		assertEquals(d, iteratorAge.previous());
		assertEquals(c, iteratorAge.previous());
		assertEquals(b, iteratorAge.previous());
		assertEquals(a, iteratorAge.previous());
		
		try{
			//no more elements in list
			iteratorAge.previous();
			assertTrue("Did not throw a NoSuchElementException",false);
		}
		catch (NoSuchElementException e)
		{
			assertTrue("Successfully threw a NoSuchElementException",true);
		}
		catch (Exception e)
		{
			assertTrue("Threw an exception other than the NoSuchElementException", false);
		}
		
	}
	
	@Test
	public void testIteratorUnsupportedOperationException() {
		linkedAge.addToFront(a);
		linkedAge.addToEnd(d);
		ListIterator<Age> iteratorAge = linkedAge.iterator();		
		assertEquals(true, iteratorAge.hasNext());
		assertEquals(a, iteratorAge.next());
		assertEquals(b, iteratorAge.next());
		assertEquals(c, iteratorAge.next());
		assertEquals(true, iteratorAge.hasNext());
		assertEquals(d, iteratorAge.next());
		
		try{
			//remove is not supported for the iterator
			iteratorAge.remove();
			assertTrue("Did not throw a UnsupportedOperationException",false);
		}
		catch (UnsupportedOperationException e)
		{
			assertTrue("Successfully threw a UnsupportedOperationException",true);
		}
		catch (Exception e)
		{
			assertTrue("Threw an exception other than the UnsupportedOperationException", false);
		}
		
	}
	
	@Test
	public void testRemove() {
	
		assertEquals(b, linkedAge.getFirst());
		assertEquals(c, linkedAge.getLast());
		linkedAge.addToFront(a);
		assertEquals(a, linkedAge.getFirst());
		linkedAge.remove(a, comparatorAge);
		assertEquals(b, linkedAge.getFirst());
		
		linkedAge.addToEnd(d);
		assertEquals(d, linkedAge.getLast());
		linkedAge.remove(d, comparatorAge);
		assertEquals(c, linkedAge.getLast());
		
		linkedAge.addToFront(a);
		assertEquals(a, linkedAge.getFirst());
		assertEquals(c, linkedAge.getLast());
		linkedAge.remove(b, comparatorAge);
		assertEquals(a, linkedAge.getFirst());
		assertEquals(c, linkedAge.getLast());
		
	}

	@Test
	public void testRetrieveFirstElement() {
		assertEquals(b, linkedAge.getFirst());
		linkedAge.addToFront(a);
		assertEquals(a, linkedAge.getFirst());
		assertEquals(a, linkedAge.retrieveFirstElement());
		assertEquals(b,linkedAge.getFirst());
		assertEquals(b, linkedAge.retrieveFirstElement());
		assertEquals(c,linkedAge.getFirst());
		
	}

	@Test
	public void testRetrieveLastElement() {
		assertEquals(c, linkedAge.getLast());
		linkedAge.addToEnd(d);
		assertEquals(d, linkedAge.getLast());
		assertEquals(d, linkedAge.retrieveLastElement());
		assertEquals(c,linkedAge.getLast());
		
		
	}

	private class StringComparator implements Comparator<String>
	{

		@Override
		public int compare(String arg0, String arg1) {
			// TODO Auto-generated method stub
			return arg0.compareTo(arg1);
		}
		
	}
	
	private class DoubleComparator implements Comparator<Double>
	{

		@Override
		public int compare(Double arg0, Double arg1) {
			// TODO Auto-generated method stub
			return arg0.compareTo(arg1);
		}
		
	}
	
	private class AgeComparator implements Comparator<Age>
	{

		@Override
		public int compare(Age arg0, Age arg1) {
			
			return arg0.toString().compareTo(arg1.toString());
		}
		
	}
	
	private class Age{
		int ageOfMe;
		int ageOfMom;
		int ageOfDad;
		
		public Age(int ageOfMe, int ageOfMom, int ageOfDad){
			this.ageOfMe = ageOfMe;
			this.ageOfMom = ageOfMom;
			this.ageOfDad = ageOfDad;
		}
		
		public int getAgeOfMe(){
			return ageOfMe;
		}
		public int getAgeOfMom(){
			return ageOfMom;
		}
		public int getAgeOfDad(){
			return ageOfDad;
		}
		
		public String toString() {
			return (getAgeOfMe()+" "+getAgeOfMom()+" "+getAgeOfDad());
		}
	}
}
