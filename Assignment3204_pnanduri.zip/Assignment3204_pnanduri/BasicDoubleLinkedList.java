import java.util.*;

public class BasicDoubleLinkedList<T> implements Iterable<T> {

	public class Node{
		
		private Node previous=null;
		private Node next = null;
		private T data=null;
		
		
		
		public Node(T dataPortion, Node previousNode, Node nextNode) {
			data = dataPortion;
			previous = previousNode;
			next = nextNode;
		}
		
		public Node(T x) {
			data = x;
		}	
		
		public void setPrevious(Node previousN) {
			previous = previousN;
		}
		
		public Node getPrevious() {
			return previous;
		}
		
		public void setNext(Node nextN) {
			next = nextN;
		}
		
		public Node getNext() {
			return next;
		}
		
		public T getItem() {
			return data;
		}
		
		public boolean equals(Node equalsN) {
			boolean flag = false;
			
			if (data == equalsN.getItem() && previous == equalsN.getPrevious()
					&& next == equalsN.getNext()) {
				flag = true;
			}
			return flag;
		}
		
	}

	public Node headNode, tailNode ;
	
	public int size;
	
	public BasicDoubleLinkedList() {
		headNode = null;
		tailNode = null;
		size =0;
	}
	
	
	/**
	 * 
	 * @return
	 */
	public int getSize() {
		return size;
	}
	
	/**
	 * 
	 * @param data
	 */
	public void addToEnd(T data) {
	    Node newNode = new Node(data, null, null);

	    if (tailNode != null) {
	    
	    	newNode.setPrevious(tailNode);
	        tailNode.setNext(newNode);
	        tailNode = newNode;
	   
	    } else {
	        headNode = newNode;
	        tailNode = newNode;
	    }

	    size=size+1;
	}
	
	/**
	 * 
	 * @param data
	 */
	public void addToFront(T data) {
	    Node newNode = new Node(data, null, null);

	    if (headNode != null) {
	        newNode.setNext(headNode);
	        headNode.setPrevious(newNode);
	        headNode = newNode;
	    } else {
	        headNode = newNode;
	        tailNode = newNode;
	    }

	    size++;
	}
	
	/**
	 * 
	 * @return
	 */
	public T getFirst() {
		if (headNode==null) {return null;}
		else {return headNode.getItem();}
	}
	
	/**
	 * 
	 * @return
	 */
	public T getLast() {
		if (tailNode == null) {return null;}
		
		else {return tailNode.getItem();}
		
	}
	
	/**
	 * 
	 * @author 13013
	 *
	 */
	protected class DoubleLinkedListIterator implements ListIterator<T>{
		Node previousNode = null;
		Node nextNode;
		
		/**
		 * 
		 */
		DoubleLinkedListIterator(){
			nextNode =  headNode;
		}
		
		/**
		 * 
		 */
		public boolean hasNext() {
			boolean flag = false;
			
			if (nextNode != null) {
				flag = true;
			}
			
			return flag;
		}
		
		/**
		 * 
		 */
		public boolean hasPrevious() {
			boolean flag = false;
			
			if (previousNode != null) {
				flag = true;
			}
			
			return flag;
		}
		
		
		/**
		 * 
		 */
		public T next() throws NoSuchElementException{
			if (hasNext()) {
				
			}
			else {
				throw new NoSuchElementException();
			}
			
			T x = nextNode.getItem();
			
			previousNode = nextNode;
			
			nextNode = nextNode.next;
			
			return x;
		}
		
		
		/**
		 * 
		 */
		public T previous() throws NoSuchElementException {
			if (hasPrevious()) {
				
			}
			else {
				throw new NoSuchElementException();
			}
			
			T x = previousNode.getItem();
			
			nextNode = previousNode;
			
			previousNode = previousNode.previous;
			
			return x;
		}
		
		
		public void add(T t) {
			throw new UnsupportedOperationException();
		}
		
		public void remove() {
			throw new UnsupportedOperationException();
		}
		
		
		public int nextIndex() {
			throw new UnsupportedOperationException();
		}
		
		
		public int previousIndex() {
			throw new UnsupportedOperationException();
		}
		
		public void set(T x) {
			throw new UnsupportedOperationException();
		}
		
		
		
	}
	
	public ListIterator<T> iterator() throws UnsupportedOperationException, NoSuchElementException {
		return new DoubleLinkedListIterator();
	}
	
	/**
	 * 
	 * @param target
	 * @param comparator
	 * @return
	 */
	public Node remove(T target, Comparator<T> comparator) {
	    Node currentNode = headNode;

	    while (comparator.compare(target, currentNode.getItem()) != 0 && currentNode != null) {
	        currentNode = currentNode.getNext();
	    }

	    if (currentNode == null) {
	        return null;
	    }

	    if (size == 1) {
	       
	    	headNode = null;
	        tailNode = null;
	    
	    } else {
	        if (currentNode.equals(headNode)) {
	            
	        	headNode = currentNode.getNext();
	           
	            currentNode.getNext().setPrevious(null);
	        
	        } 
	        else if (currentNode.equals(tailNode)) {
	        
	        	tailNode = currentNode.getPrevious();
	            
	        	currentNode.getPrevious().setNext(null);
	        } 
	        else {
	            currentNode.getPrevious().setNext(currentNode.getNext());
	         
	            
	            currentNode.getNext().setPrevious(currentNode.getPrevious());
	        }
	    }

	    size=size-1;
	    return currentNode;
	}
	/**
	 * 
	 * @return
	 */
	public T retrieveFirstElement() {
		if (headNode != null) {
			
			T x = headNode.getItem();
		
			if (size==1) {
			headNode = null;
			tailNode = null;
			return x;
		
			}
		
		headNode = headNode.getNext();
		
		headNode.setPrevious(null);
		return x;
	}
		return null;
	}
	
	/**
	 * 
	 * @return
	 */
	public T retrieveLastElement() {
		if (tailNode != null) {
		
			T x = tailNode.getItem();
			
			if (size==1) {
				headNode = null;
				tailNode = null;
				return x;
				
			}
			
			tailNode = tailNode.getPrevious();
			tailNode.setNext(null);
			
			size = size -1;
			return x;
		
		}
		return null;
	}
	
	/**
	 * 
	 * @return
	 */
	public ArrayList<T> toArrayList(){
		ArrayList<T> a = new ArrayList<T>();
		
		DoubleLinkedListIterator iterator = (DoubleLinkedListIterator) iterator();
		
		while (iterator.hasNext()) {
			a.add(iterator.next());
		}
		
		return a;
	}
	
}
	
	
	
	
	
	