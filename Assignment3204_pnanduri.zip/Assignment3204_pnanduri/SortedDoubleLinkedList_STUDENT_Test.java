


import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;





public class SortedDoubleLinkedList_STUDENT_Test {
	
	SortedDoubleLinkedList<Age> sortedLinkedAge;

	AgeComparator comparatorAge;
	
	public Age a=new Age(10, 40, 43);
	public Age b=new Age(18, 41, 41);
	public Age c=new Age(25, 45, 45);
	public Age d=new Age(30, 60, 61);
	public Age e=new Age(50, 86, 84);
	public Age f=new Age(1, 25, 28);

	
	
	@Before
	public void setUp() throws Exception {		
		comparatorAge = new AgeComparator();
		sortedLinkedAge = new SortedDoubleLinkedList<Age>(comparatorAge);
		
	}

	@After
	public void tearDown() throws Exception {
		
		comparatorAge = null;
		sortedLinkedAge = null;
	}

	@Test
	public void testAddToEnd() {
		try {
			sortedLinkedAge.addToEnd(a);
			assertTrue("Did not throw an UnsupportedOperationException", false);
		}
		catch (UnsupportedOperationException e)
		{
			assertTrue("Successfully threw an UnsupportedOperationException", true);
		}
		catch (Exception e)
		{
			assertTrue("Threw an exception other than the UnsupportedOperationException", false);
		}
	}

	@Test
	public void testAddToFront() {
		try {
			sortedLinkedAge.addToFront(a);
			assertTrue("Did not throw an UnsupportedOperationException", false);
		}
		catch (UnsupportedOperationException e)
		{
			assertTrue("Successfully threw an UnsupportedOperationException", true);
		}
		catch (Exception e)
		{
			assertTrue("Threw an exception other than the UnsupportedOperationException", false);
		}
	}

	@Test
	public void testIteratorSuccessfulNext() {
		sortedLinkedAge.add(a);
		sortedLinkedAge.add(b);
		sortedLinkedAge.add(c);
		sortedLinkedAge.add(d);
		ListIterator<Age> iterator = sortedLinkedAge.iterator();
		assertEquals(true, iterator.hasNext());
		assertEquals(a, iterator.next());
		assertEquals(b, iterator.next());
		assertEquals(c, iterator.next());
		assertEquals(true, iterator.hasNext());
	}

	@Test
	public void testIteratorSuccessfulCarPrevious() {
		sortedLinkedAge.add(f);
		sortedLinkedAge.add(a);
		sortedLinkedAge.add(b);
		sortedLinkedAge.add(c);
		
		ListIterator<Age> iterator = sortedLinkedAge.iterator();
		assertEquals(true, iterator.hasNext());
		assertEquals(f, iterator.next());
		assertEquals(a, iterator.next());
		assertEquals(b, iterator.next());
		assertEquals(c, iterator.next());
		assertEquals(true, iterator.hasPrevious());
		assertEquals(c, iterator.previous());
		assertEquals(b, iterator.previous());
		assertEquals(a, iterator.previous());
	}
	
	
	
	
	@Test
	public void testIteratorNoSuchElementException() {
		sortedLinkedAge.add(e);
		sortedLinkedAge.add(c);
		sortedLinkedAge.add(b);
		sortedLinkedAge.add(f);
		
		
		ListIterator<Age> iterator = sortedLinkedAge.iterator();
		
		assertEquals(true, iterator.hasNext());
		assertEquals(f, iterator.next());
		assertEquals(b, iterator.next());
		assertEquals(c, iterator.next());
		assertEquals(true, iterator.hasNext());
		assertEquals(e, iterator.next());
		try{
			
			iterator.next();
			assertTrue("Did not throw a NoSuchElementException",false);
		}
		catch (NoSuchElementException e)
		{
			assertTrue("Successfully threw a NoSuchElementException",true);
		}
		catch (Exception e)
		{
			assertTrue("Threw an exception other than the NoSuchElementException", false);
		}
	}
	
	@Test
	public void testIteratorUnsupportedOperationExceptionString() {
		sortedLinkedAge.add(e);
		sortedLinkedAge.add(c);
		sortedLinkedAge.add(b);
		sortedLinkedAge.add(d);
		
		ListIterator<Age> iterator = sortedLinkedAge.iterator();
		
		try{
			
			iterator.remove();
			assertTrue("Did not throw a UnsupportedOperationException",false);
		}
		catch (UnsupportedOperationException e)
		{
			assertTrue("Successfully threw a UnsupportedOperationException",true);
		}
		catch (Exception e)
		{
			assertTrue("Threw an exception other than the UnsupportedOperationException", false);
		}
	}

	@Test
	public void testAddCar() {
		
		sortedLinkedAge.add(a);
		sortedLinkedAge.add(b);
		sortedLinkedAge.add(c);
		assertEquals(a, sortedLinkedAge.getFirst());
		assertEquals(c, sortedLinkedAge.getLast());
		sortedLinkedAge.add(d);
		sortedLinkedAge.add(e);
		assertEquals(a, sortedLinkedAge.getFirst());
		assertEquals(e, sortedLinkedAge.getLast());
		
		assertEquals(e,sortedLinkedAge.retrieveLastElement());
		assertEquals(d, sortedLinkedAge.getLast());
	}

	@Test
	public void testRemoveFirstCar() {
		
		sortedLinkedAge.add(b);
		sortedLinkedAge.add(c);
		assertEquals(b, sortedLinkedAge.getFirst());
		assertEquals(c, sortedLinkedAge.getLast());
		sortedLinkedAge.add(a);
		assertEquals(a, sortedLinkedAge.getFirst());
		
		sortedLinkedAge.remove(a, comparatorAge);
		assertEquals(b, sortedLinkedAge.getFirst());
	}
	
	@Test
	public void testRemoveEndCar() {
		
		sortedLinkedAge.add(b);
		sortedLinkedAge.add(f);
		assertEquals(f, sortedLinkedAge.getFirst());
		assertEquals(b, sortedLinkedAge.getLast());
		sortedLinkedAge.add(d);
		assertEquals(d, sortedLinkedAge.getLast());
		
		sortedLinkedAge.remove(d, comparatorAge);
		assertEquals(b, sortedLinkedAge.getLast());
	}

	@Test
	public void testRemoveMiddleCar() {
		
		sortedLinkedAge.add(a);
		sortedLinkedAge.add(b);
		assertEquals(a, sortedLinkedAge.getFirst());
		assertEquals(b, sortedLinkedAge.getLast());
		sortedLinkedAge.add(f);
		assertEquals(f, sortedLinkedAge.getFirst());
		assertEquals(b, sortedLinkedAge.getLast());
		assertEquals(3,sortedLinkedAge.getSize());
		
		sortedLinkedAge.remove(a, comparatorAge);
		assertEquals(f, sortedLinkedAge.getFirst());
		assertEquals(b, sortedLinkedAge.getLast());
		assertEquals(2,sortedLinkedAge.getSize());
	}

	private class StringComparator implements Comparator<String>
	{

		@Override
		public int compare(String arg0, String arg1) {
			// TODO Auto-generated method stub
			return arg0.compareTo(arg1);
		}
		
	}
	
	private class DoubleComparator implements Comparator<Double>
	{

		@Override
		public int compare(Double arg0, Double arg1) {
			// TODO Auto-generated method stub
			return arg0.compareTo(arg1);
		}
		
	}
	
	private class AgeComparator implements Comparator<Age>
	{

		@Override
		public int compare(Age arg0, Age arg1) {
			
			return arg0.toString().compareTo(arg1.toString());
		}
		
	}
	
	private class Age{
		int ageOfMe;
		int ageOfMom;
		int ageOfDad;
		
		public Age(int ageOfMe, int ageOfMom, int ageOfDad){
			this.ageOfMe = ageOfMe;
			this.ageOfMom = ageOfMom;
			this.ageOfDad = ageOfDad;
		}
		
		public int getAgeOfMe(){
			return ageOfMe;
		}
		public int getAgeOfMom(){
			return ageOfMom;
		}
		public int getAgeOfDad(){
			return ageOfDad;
		}
		
		public String toString() {
			return (getAgeOfMe()+" "+getAgeOfMom()+" "+getAgeOfDad());
		}
	}
}
