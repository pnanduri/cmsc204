import static org.junit.Assert.*;
import org.junit.Test;

public class Road_STUDENT_Test {

	@Test
	public void testGetName() {
		Road roads = new Road(new Town("London"), new Town("Gaithersburg"), 18, "Riffle_Road");
		assertEquals("Riffle_Road", roads.getName());
	}

	@Test
	public void testGetSource() {
		Town town1 = new Town("London");
		Town town2 = new Town("Gaithersburg");
		Road roads = new Road(town1, town2, 18, "Riffle_Road");
		assertEquals(town1, roads.getSource());
	}

	@Test
	public void testGetDestination() {
		Town town1 = new Town("London");
		Town town2 = new Town("Gaithersburg");
		Road roads = new Road(town1, town2, 18, "Riffle_Road");
		assertEquals(town2, roads.getDestination());
	}

	@Test
	public void testGetWeight() {
		Road r = new Road(new Town("town1"), new Town("town2"), 18, "Darnestown");
		assertEquals(18, r.getWeight());
	}

	@Test
	public void testHashcode() {
		Road r = new Road(new Town("town1"), new Town("town2"), 18, "QO");
		assertEquals(2590, r.hashCode());
	}

	@Test
	public void testToString() {
		Road r = new Road(new Town("town1"), new Town("town2"), 74, "Mateny_Road");
		assertEquals("Mateny_Road", r.toString());
	}

	@Test
	public void testContains() {
		Town town1 = new Town("town1");
		Town town2 = new Town("town2");
		Road roads = new Road(town1, town2, 18, "Riffle_Road");
		assertEquals(true, roads.contains(town2));
		assertEquals(false, roads.contains(new Town("Praharsh")));
	}
}