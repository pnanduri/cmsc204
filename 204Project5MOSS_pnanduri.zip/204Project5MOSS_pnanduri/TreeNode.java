public class TreeNode<T> {
    	private T data;
   protected TreeNode<T> left;
   protected TreeNode<T> right;
  
  public TreeNode(T dataNode) {
   	left=null;
       right=null;
   data=dataNode;
   }
   public TreeNode(TreeNode<T> node) {
       this(node.left,node.right,node.getData());
   }
   
   public TreeNode(TreeNode<T> left,TreeNode<T> right,T info) {
       data= info;
       left=new TreeNode<T>(left);
       right=new TreeNode<T>(right);
   }
    
   public T getData() {
       return data;
   }
}