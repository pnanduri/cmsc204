import java.util.Set;
import java.util.HashSet;
import java.lang.Comparable;

public class Town implements Comparable<Town> {
	//Create variables
	protected String name = "";
	
	protected int weight = Integer.MAX_VALUE;
	protected Town townPrev = null;
	protected Set<Town> towns = new HashSet<Town>(); //create new Set

	/**
	 * 
	 * @param name
	 */
	public Town(String name) {
		//Constructor
		this.name = name;
	}

	/**
	 * 
	 * @param templateTown
	 */
	public Town(Town templateTown) {
		//Constructor to set the variables
		this.name = templateTown.name;
		
		this.towns = templateTown.towns;
		this.townPrev = templateTown.townPrev;
		this.weight = templateTown.weight;
	}
	
	
	
	/**
	 * 
	 */
	@Override
	public boolean equals(Object obj) {
	    //if obj is empty
		if (obj == null) {
	    	return false;
	    	}
	    if (!(obj instanceof Town)) {
	    	return false;
	    	}
	    Town obj2 = (Town) obj;
	    return this.name.equalsIgnoreCase(obj2.name);
	}
	
	/**
	 * 
	 */
	@Override
	public int compareTo(Town o) {
		return this.name.compareTo(o.name);
	}
	
	/**
	 * 
	 * @return
	 */
	public String getName() {
		return this.name;
	}
	

	
	/**
	 * 
	 */
	public String toString() {
		return this.getName();
	}
	/**
	 * 
	 */
	@Override
	public int hashCode() {
		return this.name.hashCode();
	
	}
	
}