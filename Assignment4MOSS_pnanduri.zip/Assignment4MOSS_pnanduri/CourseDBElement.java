public class CourseDBElement implements Comparable<CourseDBElement>{
    
private String courseID;
private int CRN;
private int credits;
private String roomNo;
private String instructor;
    
    /**
     * 
     * @param courseID
     * @param CRN
     * @param credits
     * @param roomNo
     * @param instructor
     */
    public CourseDBElement(String courseID, int CRN, int credits, String roomNo, String instructor){
       this.courseID = courseID;
       this.CRN = CRN;
       this.credits = credits;
       this.roomNo = roomNo;
       this.instructor = instructor;
    }

    /**
     * 
     */
    public CourseDBElement() {
       this(null, 0, 0, null, null);
    }

    
    /**
     * 
     */
    @Override
 public String toString() {
    return "\nCourse:"+courseID+" CRN:"+CRN+" Credits:"+credits+" Instructor:"+instructor+
    			" Room:"+roomNo;
    }

    /**
     * 
     * @return
     */
 public int getCRN(){
       return CRN;
    }

    /**
     * 
     * @return
     */
 public String getID(){
       return courseID;
    }

    /**
     * 
     * @return
     */
 public int getCredits(){
       return credits;
    }

    /**
     * 
     * @return
     */
 public String getRoomNum(){
       return roomNo;
    }
    /**
     * 
     * @return
     */
 public String getInstructor(){
       return instructor;
    }

    /**
     * 
     * @param CRN
     */
 public void setCRN(int CRN) {
       this.CRN = CRN;
    }

    /**
     * 
     * @param courseID
     */
 public void setID(String courseID) {
       this.courseID = courseID;
    }

    /**
     * 
     * @param noOfCredits
     */
 public void setCredits(int credits) {
       this.credits = credits;
    }

    /**
     * 
     * @param roomNo
     */
 public void setRoomNum(String roomNo) {
       this.roomNo = roomNo;
    }
/**
 * 
 * @param instructor
 */
 public void setInstructor(String instructor) {
       this.instructor = instructor;
    }
   
    /**
    *  
    */
    @Override
 public int compareTo(CourseDBElement x) {
       return Integer.compare(CRN, x.CRN);
    }
}
