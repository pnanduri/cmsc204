import static org.junit.Assert.*;
import org.junit.Test;

public class Town_STUDENT_Test {
	@Test
	public void testGetName() {
		Town town1 = new Town("Gaithersburg");
		Town town2 = new Town("Germantown");
		assertEquals("Gaithersburg", town1.getName());
		assertEquals("Germantown", town2.getName());
	}

	@Test
	public void testHashcode() {
		Town town1 = new Town("Gaithersburg");
		Town town2 = new Town("Germantown");
		assertEquals(-915849877, town1.hashCode());
		assertEquals(-1284114120, town2.hashCode());
	}

	@Test
	public void testToString() {
		Town town1 = new Town("Gaithersburg");
		Town town2 = new Town("Germantown");
		assertEquals("Gaithersburg", town1.toString());
		assertEquals("Germantown", town2.toString());
	}

	@Test
	public void testEqualsTown() {
		Town town1 = new Town("Gaithersburg");
		Town town2 = new Town("Germantown");
		assertFalse(town1.equals(town2));
		assertTrue(town2.equals(town2));
	}
}