import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.Collator;
import java.util.*;

public class TownGraphManager implements TownGraphManagerInterface {
	//Create Graph
	protected GraphInterface<Town, Road> TownGraph = new Graph();
	
	/**
	 * Adds a road with 2 towns and a road name
	 * @param town1 name of town 1 (lastname, firstname)
	 * @param town2 name of town 2 (lastname, firstname)
	 * @param roadName name of road
	 * @return true if the road was added successfully
	 */
	@Override
	public boolean addRoad(String town1, String town2, int weight, String roadName) {
	    boolean flag = false;
	    //Set the source and destination variables
	    Town source = this.getTown(town1);
	    Town destination = this.getTown(town2);
	    //if all is true
	    if (source!=null && destination!=null && !this.TownGraph.containsEdge(source, destination)) {
	        this.TownGraph.addEdge(source, destination, weight, roadName);
	        flag = true;
	    }

	    return flag;
	}
	
	/**
	 * Returns the name of the road that both towns are connected through
	 * @param town1 name of town 1 (lastname, firstname)
	 * @param town2 name of town 2 (lastname, firstname)
	 * @return name of road if town 1 and town2 are in the same road, returns null if not
	 */
	@Override
	public String getRoad(String town1, String town2) {
		//Create roadFlag
		Road roadFlag = this.TownGraph.getEdge(new Town(town1), new Town(town2));
		
		//If it is empty
		if (roadFlag == null) {
		    return "";
		} else {
		    return roadFlag.getName(); //return the name
		}
	}
	
	/**
	 * Adds a town to the graph
	 * @param v the town's name  (lastname, firstname)
	 * @return true if the town was successfully added, false if not
	 */
	@Override
	public boolean addTown(String v) {
		//Create newTown variable
		boolean newTown = this.TownGraph.addVertex(new Town(v));
		return newTown;
	}

	/**
	 * Gets a town with a given name
	 * @param name the town's name 
	 * @return the Town specified by the name, or null if town does not exist
	 */
	@Override
	public Town getTown(String name) {
	   //Create towns
		Set<Town> towns = this.TownGraph.vertexSet();
	    //iterate through the towns
	    for (Town newTown : towns) {
	    	//the names are equal
	        if (newTown.getName().equals(name)) {
	            return newTown;
	        }
	    }
	    
	    return null;
	}
	
	/**
	 * Determines if a town is already in the graph
	 * @param v the town's name 
	 * @return true if the town is in the graph, false if not
	 */
	@Override
	public boolean containsTown(String v) {
		//create new town
		Town town = this.getTown(v);
		boolean flag = false;
		
		//if the town is empty
		if (town != null) {
		    flag=true;
		}
		
		return flag;
	}

	

	/**
	 * Determines if a road is in the graph
	 * @param town1 name of town 1 (lastname, firstname)
	 * @param town2 name of town 2 (lastname, firstname)
	 * @return true if the road is in the graph, false if not
	 */
	@Override
	public boolean containsRoadConnection(String town1, String town2) {
		boolean hasConnection = this.TownGraph.containsEdge(this.getTown(town1), this.getTown(town2));
		
		return hasConnection;
	}
	
	/**
	 * Deletes a road from the graph
	 * @param town1 name of town 1 (lastname, firstname)
	 * @param town2 name of town 2 (lastname, firstname)
	 * @param roadName the road name
	 * @return true if the road was successfully deleted, false if not
	 */
	@Override
	public boolean deleteRoadConnection(String town1, String town2, String road) {
		//create towns
		Town newTown1 = this.getTown(town1);
		Town newTown2 = this.getTown(town2);
		Road newRoad = null;
		boolean roadFlag = true;

		//if towns are empty
		if (newTown1 != null && newTown2 != null) {
		    newRoad = this.TownGraph.removeEdge(newTown1, newTown2, -1, road);
		}

		//if road is empty
		if (newRoad == null) {
		    roadFlag=false;
		} 
		
		return roadFlag;
		
	}

	/**
	 * Creates an arraylist of all road titles in sorted order by road name
	 * @return an arraylist of all road titles in sorted order by road name
	 */
	@Override
	public ArrayList<String> allRoads() {
		//Create ArrayList
	    ArrayList<String> list = new ArrayList<String>();
	    //Create set
	    Set<Road> roadSet = this.TownGraph.edgeSet();
	    //Create iterator
	    Iterator<Road> iter = roadSet.iterator();
	    //Create a sorted List
	    ArrayList<String> sortedList = new ArrayList<String>();
	    //While there are more to iterate
	    while (iter.hasNext()) {
	        Road roads = iter.next();
	        list.add(roads.toString());
	    }
	    
	    
	    //Add to the sortted List
	    for (int count = 0; count < list.size(); count++) {
	        sortedList.add(list.get(count));
	    }
	    
	    //iterate through the sortedList
	    for (int count = 0; count < sortedList.size() - 1; count++) {
	        String string1 = sortedList.get(count);
	        int i = count;
	        
	        //put it into the current string
	        for (int x = count + 1; x < sortedList.size(); x++) {
	            String currentString = sortedList.get(x);
	            
	            //if it is smaller
	            if (Collator.getInstance().compare(currentString, string1) < 0) {
	                string1 = currentString;
	                i = x;
	            }
	        }
	        //if i is not equal to count
	        if (i != count) {
	            String tempVar = sortedList.get(count);
	            sortedList.set(count, string1);
	            sortedList.set(i, tempVar);
	        }
	    }
	    
	    return sortedList;
	}
	
	/**
	 * Deletes a town from the graph
	 * @param v name of town (lastname, firstname)
	 * @return true if the town was successfully deleted, false if not
	 */
	@Override
	public boolean deleteTown(String v) {
		//create deleteTown variable
		boolean dTown = this.TownGraph.removeVertex(this.getTown(v));
		return dTown;
	}
	
	/**
	 * Creates an arraylist of all towns in alphabetical order (last name, first name)
	 * @return an arraylist of all towns in alphabetical order (last name, first name)
	 */
	@Override
	public ArrayList<String> allTowns() {
	    //Create new sets
		Set<Town> towns = this.TownGraph.vertexSet();
	    Set<String> townNames = new TreeSet<>();
	    //iterate through the towns and add to the second set
	    for (Town townss : towns) {
	        townNames.add(townss.toString());
	    }
	    //return the tree set
	    return new ArrayList<>(townNames);
	}

	/**
	 * Returns the shortest path from town 1 to town 2
	 * @param town1 name of town 1 (lastname, firstname)
	 * @param town2 name of town 2 (lastname, firstname)
	 * @return an Arraylist of roads connecting the two towns together, null if the
	 * towns have no path to connect them.
	 */
	@Override
	public ArrayList<String> getPath(String town1, String town2) {
		//Create new path list
		ArrayList<String> pathList = this.TownGraph.shortestPath(this.getTown(town1), this.getTown(town2));
		return pathList;
	}

	/**
	 * 
	 * @param file
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public void populateTownGraph(File file) throws FileNotFoundException, IOException {
	   
		try (Scanner scanner = new Scanner(file)) {
	        while (scanner.hasNextLine()) {
	        	//create line
	            String str = scanner.nextLine(); //Create new string
	            String[] nStr = str.split(";");
	            //Create road
	            String road = nStr[0]; //new string
	            String[] nRoad = road.split(",");
	            //Create name
	            String name = nRoad[0].trim(); //new Road
	            int weight = Integer.parseInt(nRoad[1].trim());
	            
	            //Create new source
	            String source = nStr[1].trim();
	            
	            //Create new destination
	            String destination = nStr[2].trim();
	            
	            //add source, destination, and weight, name
	            this.addTown(source);
	            this.addTown(destination);
	            this.addRoad(source, destination, weight, name);
	        }
	    }
	}
	/**
	 * 
	 * @param file
	 * @return
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	protected ArrayList<String> readFile(File file) throws FileNotFoundException, IOException {
		//Create new list
		ArrayList<String> list = new ArrayList<String>();
		Scanner scanner = new Scanner(file);
		
		
		while (scanner.hasNextLine()) { //while there is more
			list.add(scanner.nextLine());
		}
		
		//close the scanner
		scanner.close();
		return list;
	}
}