import static org.junit.Assert.*;
import java.util.ArrayList;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TownGraphManager_STUDENT_Test {

    private TownGraphManagerInterface graph;
    private String[] town;

    @Before
    public void setUp() throws Exception {
        graph = new TownGraphManager();
        town = new String[4];

        for (int i = 1; i < 4; i++) {
            town[i] = "Town_" + i;
            graph.addTown(town[i]);
        }

        graph.addRoad(town[1], town[2], 7, "Riffle");
        graph.addRoad(town[2], town[3], 4, "QO");
    }

    @After
    public void tearDown() throws Exception {
        graph = null;
    }

    @Test
    public void testAddRoad() {
        ArrayList<String> roads = graph.allRoads();
        assertEquals("QO", roads.get(0));
        assertEquals("Riffle", roads.get(1));
        graph.addRoad(town[1], town[3], 4, "Germantown");
        roads = graph.allRoads();
        assertEquals("Germantown", roads.get(0));
        assertEquals("QO", roads.get(1));
        assertEquals("Riffle", roads.get(2));
    }

    @Test
    public void testGetRoad() {
        assertEquals("Riffle", graph.getRoad(town[1], town[2]));
        assertEquals("QO", graph.getRoad(town[2], town[3]));
    }

    @Test
    public void testAddTown() {
        assertEquals(false, graph.containsTown("Gaithersburg"));
        graph.addTown("Gaithersburg");
        assertEquals(true, graph.containsTown("Gaithersburg"));
    }

    @Test
    public void testDisjointGraph() {
        assertEquals(false, graph.containsTown("Town_4"));
        graph.addTown("Town_4");
        ArrayList<String> path = graph.getPath(town[1], "Town_4");
        assertFalse(path.size() > 0);
    }

    @Test
    public void testContainsTown() {
        assertEquals(true, graph.containsTown("Town_2"));
        assertEquals(false, graph.containsTown("Town_4"));
    }

    @Test
    public void testContainsRoadConnection() {
        assertEquals(true, graph.containsRoadConnection(town[2], town[3]));
        assertEquals(false, graph.containsRoadConnection(town[1], town[3]));
    }

    @Test
    public void testAllRoads() {
        ArrayList<String> roads = graph.allRoads();
        assertEquals("QO", roads.get(0));
        assertEquals("Riffle", roads.get(1));
    }

    @Test
    public void testDeleteRoadConnection() {
        assertEquals(true, graph.containsRoadConnection(town[1], town[2]));
        graph.deleteRoadConnection(town[1], town[2], "Riffle");
        assertEquals(false, graph.containsRoadConnection(town[1], town[2]));
    }

    @Test
    public void testDeleteTown() {
        assertEquals(true, graph.containsTown("Town_2"));
        graph.deleteTown(town[2]);
        assertEquals(false, graph.containsTown("Town_2"));
    }
    
    @Test
    public void testAllTowns() {
    ArrayList<String> roads = graph.allTowns();
    assertEquals("Town_1", roads.get(0));
    assertEquals("Town_2", roads.get(1));
   }
    
  
    @Test 
    public void testGetPath() {
    	ArrayList<String> path = graph.getPath(town[1], town[2]);
    	assertNotNull(path);
    	assertTrue(path.size()>0);
    	assertEquals("Town_1 via Riffle to Town_2 7 mi", path.get(0).trim());
    }
    
    @Test
    public void testGetPathA() {
    	ArrayList<String> path = graph.getPath(town[1], town[3]);
    	assertNotNull(path);
    	assertTrue(path.size()>0);
    	assertEquals("Town_2 via QO to Town_3 4 mi", path.get(1).trim());
    }
    
    @Test
    public void testGetPathB() {
    	ArrayList<String> path = graph.getPath(town[2], town[3]);
    	assertNotNull(path);
    	assertTrue(path.size()>0);
    	assertEquals("Town_2 via QO to Town_3 4 mi", path.get(0).trim());
    }
   }