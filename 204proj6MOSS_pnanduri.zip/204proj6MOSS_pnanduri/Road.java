import java.lang.Comparable;
public class Road implements Comparable<Road> {

	//Create Town variables
	protected int degrees = 0;
	protected Town source = null;
	protected String name = "";
	protected Town destination = null;
	
	
	
	/**
	 * 
	 * @param source
	 * @param destination
	 * @param degrees
	 * @param name
	 */
	public Road(Town source, Town destination, int degrees, String name) {
		//Constructor/set the variables
		this.source = source;
		this.name = name;
		this.destination = destination;
		this.degrees = degrees;
		
	}

	/**
	 * 
	 * @param source
	 * @param destination
	 * @param name
	 */
	public Road(Town source, Town destination, String name) {
		//Constructor no. 2
		this.source = source;
		this.destination = destination;
		this.degrees = 1;
		this.name = name;
	}
	
	
	
	/**
	 * 
	 * @return
	 */
	public Town getSource() {
		return this.source;
	}
	
	/**
	 * 
	 * @return
	 */
	public String getName() {
		return this.name;
	}
	
	/**
	 * 
	 * @return
	 */
	public Town getDestination() {
		return this.destination;
	}
	
	/**
	 * 
	 */
	@Override
	public String toString() {
		return this.name;
	}
	
	/**
	 * 
	 */
	@Override
	public int compareTo(Road o) {
		//return the weight
		return this.getWeight() - o.getWeight();
	}
	
	/**
	 * 
	 * @return
	 */
	public int getWeight() {
		return this.degrees;
	}
	
	/**
	 * 
	 */
	@Override
	public int hashCode() {
		return this.name.hashCode();
	}
	
	
	
	/**
	 * 
	 * @param town
	 * @return
	 */
	public boolean contains(Town town) {
		if (this.source.equals(town) || this.destination.equals(town)) {
			return true;
		}
		
		return false;
		
		
	}

	/**
	 * 
	 */
	@Override
	public boolean equals(Object r) {
		boolean sourceE=false;
		boolean destinationE=false;
		
		Road newRoad = (Road) r; //create new road
		//if it is equal to r
		if (this == r) {
	        return true;
	    }
	    
	    if (!(r instanceof Road)) {
	        return false;
	    }
	    
	  //if either or is equal
	    if (this.source.equals(newRoad.source)||this.source.equals(newRoad.destination)) { 
	    	
	    	sourceE = true;
	    }
	    
	    //if either or is equal
	    if (this.destination.equals(newRoad.source)||this.destination.equals(newRoad.destination)) {
	    	destinationE = true;
	    }
	    //if both are true
	    if (sourceE && destinationE) {
	    	return true;
	    }
	    else {
	    	return false;
	    }
	}
	
	
}