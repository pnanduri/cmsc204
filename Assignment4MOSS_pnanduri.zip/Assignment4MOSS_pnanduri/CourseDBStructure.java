import java.io.IOException;
import java.util.LinkedList;
import java.util.ArrayList;

public class CourseDBStructure implements CourseDBStructureInterface{
   
	private LinkedList<CourseDBElement>[] h;
	private int t;
    
/**
 * 
 * @param x
 */
    public CourseDBStructure(int x){
        int size = (int)(x/1.5);
        
        t = findPrime(size);
        
        h = new LinkedList[t];
        for(int count= 0; count<t; count++){
            
        	h[count]=new LinkedList<CourseDBElement>();
        }
    }
   
    
    //Testing constructor
    /**
     * 
     * @param a
     * @param b
     */
    public CourseDBStructure(String a, int b){
        this.t = b;
        
        h = new LinkedList[t];
        
        for(int count= 0; count<t; count++){
            h[count]=new LinkedList<CourseDBElement>();
        }
    }
    
    /**
	* Returns the size of the ConcordanceDataStructure (number of indexes in the array)
	*/
    public int getTableSize(){
        return t;
    }

    /** 
	* Adds a CourseDBElement object to the CourseDBStructure using the hashcode
	* of the CourseDatabaseElemen object's crn value.
	* If the CourseDatabaseElement already exists, exit quietly
	*  
	* @param element the CourseDBElement to be added to CourseDBStructure
	*/
  public void add(CourseDBElement element) {
       
   int i = Integer.toString(element.getCRN()).hashCode()%t;
       
     LinkedList<CourseDBElement> courseList = h[i];
        
     if (courseList.isEmpty()) {
         courseList.add(element);
        } 
        else
        {
            boolean flag = false;
            for (int count = 0; count < courseList.size(); count++) {
        
         	CourseDBElement el = courseList.get(count);
                
           	if (el.getCRN() == element.getCRN()) {
                    
              	courseList.set(count, element);
                   flag = true;
                   break;
                }
            }
            if (flag) {
               
            }
            else {
            	 courseList.add(element);
            }
        }
    }
    
    /**
	 * Find a courseDatabaseElement based on the key (crn) of the
	 * courseDatabaseElement If the CourseDatabaseElement is found return it If not,
	 * throw an IOException
	 * 
	 * @param crn crn (key) whose associated courseDatabaseElement is to be returned
	 * @return a CourseDBElement whose crn is mapped to the key
	 * @throws IOException if key is not found
	 */
 public CourseDBElement get(int crn) throws IOException {
        
   int hashCode = Integer.toString(crn).hashCode();
        
   int index = hashCode % t;
        
   if (h[index] == null) {    
    	throw new IOException();
    }
        
       LinkedList<CourseDBElement> list = h[index];
        
       for (int count = 0; count < list.size(); count++) {
           CourseDBElement x = list.get(count);
           if (x.getCRN() == crn) {
               return x;            }
       }
       throw new IOException();
   }

    /**
	 * @return an array list of string representation of each course in 
	 * the data structure separated by a new line. 
	 * Refer to the following example:
	 * Course:CMSC500 CRN:39999 Credits:4 Instructor:Nobody InParticular Room:SC100
	 * Course:CMSC600 CRN:4000 Credits:4 Instructor:Somebody Room:SC200
	 */
 public ArrayList<String> showAll() {
       ArrayList<String> course1 = new ArrayList<>();
       
       for (int count = 0; count < h.length; count++) {            
        LinkedList<CourseDBElement> courseList = h[count];
            
       	if (courseList == null) {
               }
           else {
           	for (int x = 0; x < courseList.size(); x++) {
                   CourseDBElement e = courseList.get(x);
                   course1.add(e.toString());
           }
           }
       	}
       return course1;
   }

    
    /**
     * 
     * @param x
     * @return
     */
 private int findPrime(int x) {
       while (true) {
           x++;
           
           if (x%4!=3) {
               continue;
           }
           boolean isPrime = true;
           for (int count = 2; count < x; count++) {
               if (x % count == 0) {
                   isPrime = false;
                   break;
               }
           }
           if (isPrime) {
               return x;
           }
       }
   }
}
