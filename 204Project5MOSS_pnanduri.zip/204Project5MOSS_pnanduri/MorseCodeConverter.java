import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class MorseCodeConverter {

 private static MorseCodeTree tree=new MorseCodeTree();

 /**
  * 
  * @return
  */
 public static String printTree() {
  String printer="";
   
  //Create new ArrayList
  ArrayList<String>list=new ArrayList<String>();
   list=tree.toArrayList();
  
   //Building the printer
   for(int count=0;count<list.size();count++) {
    
	   printer += list.get(count);
   }
  
   return printer.substring(0, printer.length()-1);
 } 
 
 /**
  *  
  * @param code
  * @return
  */
  public static String convertToEnglish(String code) {
   StringBuilder endCode = new StringBuilder();
  
   //Create variables that correspond the code
   int codeLength = code.length();
  int codeBegin = 0;
  
 for (int count = 0; count < codeLength; count++) {          
   if (code.charAt(count) == ' ') {
    //Create substring
	String morse = code.substring(codeBegin, count);
         if (morse.equals("/")) 
         {
                endCode.append(" ");
             }
              else 
              {
                  endCode.append(tree.fetch(morse));
              }
              codeBegin=count+1;
          }
      }
      
 //Create a new substring of the morse code
 String morse = code.substring(codeBegin);
      if (!morse.isEmpty()) 
      {
          if (morse.equals( "/" )) {
              endCode.append( " " );
          } else {
              endCode.append(tree.fetch(morse));
          }
      }
      //return the end code
      return endCode.toString();
  }  
  
/**
 *  
 * @param codeFile
 * @return
 * @throws FileNotFoundException
 */
  public static String convertToEnglish(File codeFile) throws FileNotFoundException {
      StringBuilder str = new StringBuilder();
      
      try (Scanner scan = new Scanner(codeFile)) {
          //while there is more input, convert to English
    	  while (scan.hasNextLine()) {
              String code = scan.nextLine();
              str.append(convertToEnglish(code));
          }
      }
      //return the final string.
      return str.toString();
  }
}