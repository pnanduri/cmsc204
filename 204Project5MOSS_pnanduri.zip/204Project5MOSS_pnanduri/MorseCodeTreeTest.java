import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MorseCodeTreeTest {
	
protected MorseCodeTree tree;	
	@Before
public void setUp() throws Exception {
	tree = new MorseCodeTree();
}
	@After
public void tearDown() throws Exception {
	tree = null;
}
	@Test
public void testGetRoot() {
	assertEquals(tree.getRoot().getData(), "");
}
	@Test
public void testInsert() {
tree.insert(".-", "a");
	tree.insert("-.-.", "c");
	
	assertEquals(tree.fetch("_._"), "k");
assertEquals(tree.fetch("."), "e");
}
	@Test
public void testAddNode() {	
}
@Test
public void testFetch() {
	tree.insert(".--.", "p");
	assertEquals(tree.fetch(".--."), "p");
		
	tree.insert(".-..", "l");
assertEquals(tree.fetch(".-.."), "l");
}
@Test
public void testFetchNode() {	
	}

@Test
public void testBuildTree() {
	
}
	@Test
public void testToArrayList() {
	
	String endCode = "";
ArrayList<String> strTree = tree.toArrayList();	
	for (int count = 0; count < strTree.size(); count++) {
	    String str = strTree.get(count);
    endCode += str + " ";
}		
endCode = endCode.trim();	
	assertEquals("h  s  v  i  f  u  e  l  r  a  p  w  j    b  d  x  n  c  k  y  t  z  g  q  m  o", endCode);
}
@Test
public void testLNRoutputTraversal() {	
	}
}